#include <iostream>
using namespace std;

int prod(){
    int total=0;
    const int a=2;
    static int b=0;
    
    total = a*b;
    
    b++;
    return total;
}


int main(){
    
    int max=0;
    while(max < 10){
        
        int pr = prod();
        
        cout << pr << endl;
        
        max++;
    }

    return 0;
}